import gen
import add_noise
import numpy as np
index = np.linspace(0,50*10000,endpoint=False,num=50,dtype = int)
print(np.linspace(1,50,dtype = int))
print(max(1,2))